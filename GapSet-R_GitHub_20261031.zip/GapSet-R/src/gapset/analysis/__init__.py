"""GapSet research code."""
